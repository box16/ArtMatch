from django.contrib import admin

from .models import Article, Interest, PositiveWord, NegativeWord

admin.site.register(Article)
admin.site.register(Interest)
